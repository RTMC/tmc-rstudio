library(testthat)
library(tmcrstudioaddin)

test_check("tmcrstudioaddin")
